'use strict';

// DEMO ONLY: replace these illustrative values with verified, server-managed rates before launch.
const SAMPLE_RATES_NGN_PER_USD = Object.freeze({ apple: 300, amazon: 285, steam: 275, google: 265, razer: 270, itunes: 290 });
const CARD_NAMES = Object.freeze({ apple: 'Apple Gift Card', amazon: 'Amazon', steam: 'Steam', google: 'Google Play', razer: 'Razer Gold', itunes: 'iTunes' });
const $ = (id) => document.getElementById(id);
const form = $('estimateForm');
const brandSelect = $('giftCard');
const amountInput = $('amount');
const errorBox = $('formError');
const dialog = $('tradeDialog');
const moneyNGN = new Intl.NumberFormat('en-NG', { maximumFractionDigits: 2 });
const moneyUSD = new Intl.NumberFormat('en-US', { style: 'currency', currency: 'USD' });

function readEstimate() {
  const brand = brandSelect.value;
  const amount = Number(amountInput.value);
  if (!Object.hasOwn(SAMPLE_RATES_NGN_PER_USD, brand)) return { error: 'Please choose a supported card type.' };
  if (amountInput.value.trim() === '' || !Number.isFinite(amount) || amount < 1 || amount > 10000) {
    return { error: 'Enter a card value between $1 and $10,000.' };
  }
  const rate = SAMPLE_RATES_NGN_PER_USD[brand];
  const naira = Math.round((amount * rate + Number.EPSILON) * 100) / 100;
  if (!Number.isFinite(naira)) return { error: 'We could not calculate that amount. Please check the value.' };
  return { brand, amount, rate, naira };
}

function showError(message) {
  errorBox.textContent = message || '';
  errorBox.hidden = !message;
  if (message) $('nairaValue').textContent = '—';
}

function renderEstimate() {
  const estimate = readEstimate();
  if (estimate.error) { showError(estimate.error); return null; }
  showError('');
  $('nairaValue').textContent = moneyNGN.format(estimate.naira);
  $('rateValue').textContent = `₦${moneyNGN.format(estimate.rate)} / $1`;
  $('resultName').textContent = CARD_NAMES[estimate.brand];
  $('usdValue').textContent = `${moneyUSD.format(estimate.amount)} USD`;
  $('heroNaira').textContent = moneyNGN.format(100 * SAMPLE_RATES_NGN_PER_USD.apple);
  return estimate;
}

form.addEventListener('submit', (event) => {
  event.preventDefault();
  const estimate = renderEstimate();
  if (!estimate) amountInput.focus();
});
brandSelect.addEventListener('change', renderEstimate);
amountInput.addEventListener('input', () => { if (!errorBox.hidden || amountInput.value) renderEstimate(); });

function openTradePreview() {
  const estimate = renderEstimate();
  if (!estimate) { amountInput.focus(); return; }
  $('previewName').textContent = CARD_NAMES[estimate.brand];
  $('previewUsd').textContent = `${moneyUSD.format(estimate.amount)} USD`;
  $('previewNaira').textContent = `₦${moneyNGN.format(estimate.naira)}`;
  if (typeof dialog.showModal === 'function') dialog.showModal();
  else window.alert(`Indicative estimate: ₦${moneyNGN.format(estimate.naira)}. Demo only; no trade has been submitted.`);
}
$('tradeButton').addEventListener('click', openTradePreview);
document.querySelectorAll('[data-card]').forEach((button) => {
  button.addEventListener('click', () => {
    brandSelect.value = button.dataset.card;
    renderEstimate();
    $('converter').scrollIntoView({ behavior: 'smooth', block: 'start' });
  });
});

const menuToggle = $('menuToggle');
const nav = $('mainNav');
menuToggle.addEventListener('click', () => {
  const isOpen = nav.classList.toggle('open');
  menuToggle.setAttribute('aria-expanded', String(isOpen));
  menuToggle.setAttribute('aria-label', isOpen ? 'Close menu' : 'Open menu');
});
nav.querySelectorAll('a').forEach((link) => link.addEventListener('click', () => {
  nav.classList.remove('open');
  menuToggle.setAttribute('aria-expanded', 'false');
  menuToggle.setAttribute('aria-label', 'Open menu');
}));
$('year').textContent = String(new Date().getFullYear());
renderEstimate();
